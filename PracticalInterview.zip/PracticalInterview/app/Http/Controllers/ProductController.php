<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categoryData =  ProductCategory::all();
        $productObj = new Product;
        $productDetails = $productObj->productDetails();
        return view('viewProducts',['productDetails'=>$productDetails,'categoryData'=>$categoryData]);
    }

    public function searchProduct(Request $request)
    {

        $searchData = [];

        $searchData['productName'] = !empty($request->searchName)?$request->searchName:'';
        $searchData['categoryId'] = !empty($request->categoryId)?$request->categoryId:'';
        $categoryData =  ProductCategory::all();
        $productObj = new Product;
        $productDetails = $productObj->productDetails($searchData);
        return view('viewProducts',['productDetails'=>$productDetails,'categoryData'=>$categoryData]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categoryData = ProductCategory::all();
        return view('addProduct',['categoryData'=>$categoryData]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $rule = array(
            'productName' => 'required',
            'prouctDescription' => 'required',
            'productCategory' => 'required',
        );
        $validation =  $request->validate($rule);

        $productObj = new Product;
        $productObj->name = !empty($request->productName)?$request->productName:'';
        $productObj->description = !empty($request->prouctDescription)?$request->prouctDescription:'';
        $productObj->unique_code = uniqid();
        $productObj->category_id = !empty($request->productCategory)?$request->productCategory:'';
        $productObj->save();
        if($productObj){
            return redirect('viewProduct')->with('success', 'New product added successfully.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
