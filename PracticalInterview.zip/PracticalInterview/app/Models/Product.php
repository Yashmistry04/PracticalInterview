<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ProductCategory;
use DB;

class Product extends Model
{
    use HasFactory;

    protected $table = 'product';
    protected $primarykey = 'id';

     protected $fillable = [
        'id',
        'name',
        'description',
        'unique_code',
        'category_id',
        'created_at',
        'updated_at',
    ];

    public function productDetails($searchData = array())
    {
    	
    	$query = DB::table('product as p');
        $query->select('p.name as productName','p.description as description', 'c.name as categoryName','p.created_at as createdDate');
        $query->join('productcategory as c', 'p.category_id', '=', 'c.id');
        if(!empty($searchData['productName'])){
        	$query->where('p.name', 'LIKE','%'.$searchData['productName'].'%');
        }
        if(!empty($searchData['categoryId'])){
        	$query->where('p.category_id',$searchData['categoryId']);
        }
        $result = $query->get();
        return $result;
    }
   
}
