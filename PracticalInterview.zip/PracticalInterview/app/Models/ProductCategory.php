<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Product;
use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
    use HasFactory;

    protected $table = 'productcategory';
    protected $primarykey = 'id';

     protected $fillable = [
        'id',
        'name',
        'created_at',
        'updated_at',
    ];

    
}
