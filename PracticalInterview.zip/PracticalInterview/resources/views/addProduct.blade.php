<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>

<!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    </head>
<body>
<div class="container">

@if ($errors->any())
    <div class="alert alert-warning">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<h1>Add Product</h1>
{{Form::open(['url'=>route('saveProduct'),'method'=>'post','name'=>'saveProductForm','id'=>'saveProductForm'])}}
    <div class="form-group">
        <label for="productName">Name </label>
        <input  type="text"  class="form-control" name="productName" id="productName" placeholder="Please enter prouct name"  >
        
    </div>
    <div class="form-group">
        <label for="prouctDescription">Description </label>
        <textarea class="form-control" name="prouctDescription" id="prouctDescription" cols="30" rows="10"></textarea>
    </div>
   
    <div class="form-group">
        <label for="productCategory">Example select</label>
        <select class="form-control" id="productCategory" name="productCategory">
        <option value="">Please select prouct category</option>
        @foreach($categoryData as $category)
        <option value="{{$category->id}}">{{$category->name}}</option>
        @endforeach
        </select>
    </div>
    <input type="submit" id="saveProductButton" class="btn btn-success" value="Add">
    <input type="reset" id="" class="btn " value="reset">
   {{Form::close()}}
</div>

</body>
</html>
