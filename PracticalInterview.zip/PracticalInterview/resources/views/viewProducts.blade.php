<!DOCTYPE html>
<html>
<head>
	<title>View  Product</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<div class="container">
<h1>View Product</h1>

<div class="flash-message">
  @foreach (['danger', 'warning', 'success', 'info'] as $msg)
    @if(Session::has($msg))
    <p class="alert alert-{{ $msg }}">{{ Session::get($msg) }}</p>
    @endif
  @endforeach
</div>
<div class="row">
<div class="form-group">
<a href="{{route('addProduct')}}" class="btn btn-success">Add New Product</a>
</div>
</div>
<div class="row">
{{Form::open(['url'=>route('searchProduct'),'method'=>'post','name'=>'viewProductForm','id'=>'viewProductForm'])}}
<div class="col-sm-5" >
    <div class="form-group">
      <input type="text" name="searchName" id="searchName" class="form-control" placeholder="search...">
    </div>
  </div>
  <div class="col-sm-5" >
    <div class="form-group">
    <select class="form-control" id="categoryId" name="categoryId">
        <option value="">Please select prouct category</option>
        @foreach($categoryData as $category)
        <option value="{{$category->id}}">{{$category->name}}</option>
        @endforeach
        </select>
    </div>
  </div>

  <div class="col-sm-2" >
    <div class="form-group">
    <input type="submit" class="form-control btn btn-success" value="search">
    </div>
  </div>
 
 
{{Form::close()}}
</div>
  <div class="row">
 
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Product Name</th>
            <th scope="col">Category Name</th>
            <th scope="col">Description</th>
            <th scope="col">Created Date</th>
          </tr>
        </thead>
        <tbody>
        @if(!empty($productDetails))
          @foreach($productDetails as $key => $data)
          <tr>
            <td>{{$key+1}} </td>
            <td>{{$data->productName}} </td>
            <td>{{$data->categoryName}} </td>
            <td>{{ date('d M Y h:i A',strtotime($data->createdDate)) }} </td>
           </tr>
          @endforeach
        @else
          <tr>
            <td colspan="5" class="text-center">  No records </td>
           </tr>
        @endif

        </tbody>
      </table>
  
    </div>
  </div>
</div>


        
</body>
</html>
