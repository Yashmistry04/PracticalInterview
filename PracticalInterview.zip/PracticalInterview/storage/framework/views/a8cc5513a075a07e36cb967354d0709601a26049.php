<!DOCTYPE html>
<html>
<head>
	<title>View  Product</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<div class="container">
<h1>View Product</h1>

<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has($msg)): ?>
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get($msg)); ?></p>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row">
<div class="form-group">
<a href="<?php echo e(route('addProduct')); ?>" class="btn btn-success">Add New Product</a>
</div>
</div>
<div class="row">
<?php echo e(Form::open(['url'=>route('searchProduct'),'method'=>'post','name'=>'viewProductForm','id'=>'viewProductForm'])); ?>

<div class="col-sm-5" >
    <div class="form-group">
      <input type="text" name="searchName" id="searchName" class="form-control" placeholder="search...">
    </div>
  </div>
  <div class="col-sm-5" >
    <div class="form-group">
    <select class="form-control" id="categoryId" name="categoryId">
        <option value="">Please select prouct category</option>
        <?php $__currentLoopData = $categoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
  </div>

  <div class="col-sm-2" >
    <div class="form-group">
    <input type="submit" class="form-control btn btn-success" value="search">
    </div>
  </div>
 
 
<?php echo e(Form::close()); ?>

</div>
  <div class="row">
 
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Product Name</th>
            <th scope="col">Category Name</th>
            <th scope="col">Description</th>
            <th scope="col">Created Date</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!empty($productDetails)): ?>
          <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key+1); ?> </td>
            <td><?php echo e($data->productName); ?> </td>
            <td><?php echo e($data->categoryName); ?> </td>
            <td><?php echo e(date('d M Y h:i A',strtotime($data->createdDate))); ?> </td>
           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan="5" class="text-center">  No records </td>
           </tr>
        <?php endif; ?>

        </tbody>
      </table>
  
    </div>
  </div>
</div>


        
</body>
</html>
<?php /**PATH C:\wamp64\www\PracticalInterview\resources\views/viewProducts.blade.php ENDPATH**/ ?>