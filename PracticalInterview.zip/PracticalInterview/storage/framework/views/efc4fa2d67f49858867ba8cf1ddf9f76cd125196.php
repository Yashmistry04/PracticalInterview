<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>

<!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    </head>
<body>
<div class="container">

<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<h1>Add Product</h1>
<?php echo e(Form::open(['url'=>route('saveProduct'),'method'=>'post','name'=>'saveProductForm','id'=>'saveProductForm'])); ?>

    <div class="form-group">
        <label for="productName">Name </label>
        <input  type="text"  class="form-control" name="productName" id="productName" placeholder="Please enter prouct name"  >
        
    </div>
    <div class="form-group">
        <label for="prouctDescription">Description </label>
        <textarea class="form-control" name="prouctDescription" id="prouctDescription" cols="30" rows="10"></textarea>
    </div>
   
    <div class="form-group">
        <label for="productCategory">Example select</label>
        <select class="form-control" id="productCategory" name="productCategory">
        <option value="">Please select prouct category</option>
        <?php $__currentLoopData = $categoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <input type="submit" id="saveProductButton" class="btn btn-success" value="Add">
    <input type="reset" id="" class="btn " value="reset">
   <?php echo e(Form::close()); ?>

</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\PracticalInterview\resources\views/addProduct.blade.php ENDPATH**/ ?>